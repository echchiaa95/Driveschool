export type Student = { id: string; full_name: string; phone: string; license_category: string; agreed_price: number; paid_amount: number; status: string; created_at: string };
export type Vehicle = { id: string; label: string; plate_number: string; transmission: string; status: string; mileage: number };
export type Expense = { id: string; title: string; category: string; amount: number; expense_date: string; payment_status: string };
export type ExamCard = { id: string; card_number: string; card_type: string; owner_name: string; monthly_quota: number; rental_cost: number; rental_end: string | null; status: string };
export type Post = { id: string; title: string; slug: string; category: string; status: string; published_at: string | null };
