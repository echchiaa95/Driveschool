import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders } from '../_shared/cors.ts';

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { ...corsHeaders, 'Content-Type': 'application/json' },
});

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);

  const url = Deno.env.get('SUPABASE_URL');
  const anonKey = Deno.env.get('SUPABASE_ANON_KEY');
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!url || !anonKey || !serviceKey) return json({ error: 'Server configuration missing' }, 500);

  const authHeader = req.headers.get('Authorization');
  if (!authHeader) return json({ error: 'Authentication required' }, 401);

  const userClient = createClient(url, anonKey, {
    global: { headers: { Authorization: authHeader } },
    auth: { persistSession: false },
  });
  const { data: userData, error: userError } = await userClient.auth.getUser();
  if (userError || !userData.user) return json({ error: 'Invalid session' }, 401);

  const admin = createClient(url, serviceKey, { auth: { persistSession: false } });
  const { data: profile, error: profileError } = await admin
    .from('profiles').select('role,active').eq('id', userData.user.id).maybeSingle();
  if (profileError || !profile || profile.role !== 'superadmin' || !profile.active) {
    return json({ error: 'Forbidden: superadmin role required' }, 403);
  }

  let body: Record<string, unknown>;
  try { body = await req.json(); } catch { return json({ error: 'Invalid JSON' }, 400); }
  const schoolName = String(body.school_name ?? '').trim();
  const schoolNameFr = String(body.school_name_fr ?? '').trim();
  const city = String(body.city ?? '').trim();
  const managerName = String(body.manager_name ?? '').trim();
  const email = String(body.manager_email ?? '').trim().toLowerCase();
  const password = String(body.manager_password ?? '');
  if (!schoolName || !schoolNameFr || !city || !managerName || !email || password.length < 12) {
    return json({ error: 'All fields are required; password must contain at least 12 characters.' }, 400);
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json({ error: 'Invalid email address' }, 400);

  const slugBase = schoolNameFr.toLowerCase().normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '').slice(0, 40) || 'auto-ecole';
  const slug = `${slugBase}-${crypto.randomUUID().slice(0, 8)}`;
  let schoolId: string | null = null;
  let userId: string | null = null;

  const { data: school, error: schoolError } = await admin.from('schools').insert({
    name: schoolName, name_fr: schoolNameFr, city, slug,
  }).select('id').single();
  if (schoolError || !school) return json({ error: `School creation failed: ${schoolError?.message ?? 'unknown error'}` }, 400);
  schoolId = school.id;

  const { data: created, error: createError } = await admin.auth.admin.createUser({
    email, password, email_confirm: true,
    user_metadata: { full_name: managerName, school_id: schoolId },
  });
  if (createError || !created.user) {
    await admin.from('schools').delete().eq('id', schoolId);
    return json({ error: `Manager account creation failed: ${createError?.message ?? 'unknown error'}` }, 400);
  }
  userId = created.user.id;

  const { error: profileInsertError } = await admin.from('profiles').insert({
    id: userId, school_id: schoolId, full_name: managerName,
    role: 'admin', preferred_language: 'ar', active: true,
  });
  if (profileInsertError) {
    await admin.auth.admin.deleteUser(userId);
    await admin.from('schools').delete().eq('id', schoolId);
    return json({ error: `Manager profile creation failed: ${profileInsertError.message}` }, 400);
  }

  const { error: settingsError } = await admin.from('site_settings').insert({ school_id: schoolId });
  if (settingsError) {
    await admin.auth.admin.deleteUser(userId);
    await admin.from('schools').delete().eq('id', schoolId);
    return json({ error: `School settings creation failed: ${settingsError.message}` }, 400);
  }

  return json({ success: true, school_id: schoolId, manager_id: userId });
});
