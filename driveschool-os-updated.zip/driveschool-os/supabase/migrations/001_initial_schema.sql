-- DriveSchool OS · Initial schema for a single driving school
-- Run this file in Supabase SQL Editor. Never expose the service_role key in the browser.
create extension if not exists pgcrypto;

create table if not exists public.schools (
  id uuid primary key default gen_random_uuid(),
  name text not null default 'مدرسة النجاح',
  name_fr text not null default 'Auto-école Al Najah',
  slug text not null unique default 'auto-ecole',
  phone text,
  email text,
  address text,
  city text,
  logo_url text,
  primary_color text not null default '#244a36',
  currency text not null default 'MAD' check (currency = 'MAD'),
  default_monthly_exam_quota integer not null default 12 check (default_monthly_exam_quota > 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  school_id uuid not null references public.schools(id) on delete restrict,
  full_name text not null default 'مسؤول النظام',
  role text not null default 'staff' check (role in ('admin','staff','accountant','instructor','editor')),
  preferred_language text not null default 'ar' check (preferred_language in ('ar','fr')),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.current_school_id()
returns uuid language sql stable security definer set search_path = public
as $$ select school_id from public.profiles where id = auth.uid() and active = true limit 1 $$;
create or replace function public.current_user_role()
returns text language sql stable security definer set search_path = public
as $$ select role from public.profiles where id = auth.uid() and active = true limit 1 $$;
create or replace function public.is_school_staff()
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.profiles where id = auth.uid() and active = true and role in ('admin','staff','accountant','instructor','editor')) $$;
create or replace function public.is_school_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.profiles where id = auth.uid() and active = true and role = 'admin') $$;

create table if not exists public.students (
  id uuid primary key default gen_random_uuid(), school_id uuid not null default public.current_school_id() references public.schools(id) on delete restrict,
  student_number text, full_name text not null, phone text not null, email text, national_id text,
  date_of_birth date, address text, license_category text not null default 'B',
  agreed_price numeric(12,2) not null default 0 check (agreed_price >= 0),
  paid_amount numeric(12,2) not null default 0 check (paid_amount >= 0),
  status text not null default 'active' check (status in ('active','exam_ready','documents_pending','completed','paused','cancelled')),
  registration_date date not null default current_date, notes text, created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  check (paid_amount <= agreed_price)
);
create unique index if not exists students_school_student_number_idx on public.students(school_id, student_number) where student_number is not null;
create index if not exists students_school_name_idx on public.students(school_id, full_name);
create index if not exists students_school_phone_idx on public.students(school_id, phone);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(), school_id uuid not null default public.current_school_id() references public.schools(id) on delete restrict,
  student_id uuid not null references public.students(id) on delete restrict, amount numeric(12,2) not null check(amount > 0),
  payment_date date not null default current_date, payment_method text not null default 'cash' check(payment_method in ('cash','card','bank_transfer','cheque','other')),
  receipt_number text, note text, received_by uuid references auth.users(id) on delete set null, created_at timestamptz not null default now()
);
create index if not exists payments_school_date_idx on public.payments(school_id,payment_date desc);

create table if not exists public.expense_categories (
  id uuid primary key default gen_random_uuid(), school_id uuid not null default public.current_school_id() references public.schools(id) on delete restrict,
  name text not null, name_fr text, active boolean not null default true, created_at timestamptz not null default now(), unique(school_id,name)
);
create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(), school_id uuid not null default public.current_school_id() references public.schools(id) on delete restrict,
  title text not null, category text not null default 'أخرى', amount numeric(12,2) not null check(amount >= 0),
  expense_date date not null default current_date, payment_status text not null default 'paid' check(payment_status in ('paid','pending','cancelled')),
  payment_method text, vendor text, receipt_url text, notes text, created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index if not exists expenses_school_date_idx on public.expenses(school_id,expense_date desc);

create table if not exists public.exam_cards (
  id uuid primary key default gen_random_uuid(), school_id uuid not null default public.current_school_id() references public.schools(id) on delete restrict,
  card_number text not null, card_type text not null check(card_type in ('owned','rented')), owner_name text not null,
  owner_phone text, rental_start date, rental_end date, rental_cost numeric(12,2) not null default 0 check(rental_cost >= 0),
  monthly_quota integer not null default 12 check(monthly_quota > 0), status text not null default 'active' check(status in ('active','expired','suspended','pending')),
  notes text, created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(school_id,card_number),
  check ((card_type = 'owned' and rental_cost = 0) or card_type = 'rented')
);
create table if not exists public.monthly_quotas (
  id uuid primary key default gen_random_uuid(), school_id uuid not null default public.current_school_id() references public.schools(id) on delete restrict,
  exam_card_id uuid not null references public.exam_cards(id) on delete restrict, quota_month date not null,
  quota_total integer not null check(quota_total >= 0), quota_reserved integer not null default 0 check(quota_reserved >= 0),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(exam_card_id,quota_month),
  check(quota_reserved <= quota_total)
);
create table if not exists public.exam_bookings (
  id uuid primary key default gen_random_uuid(), school_id uuid not null default public.current_school_id() references public.schools(id) on delete restrict,
  student_id uuid not null references public.students(id) on delete restrict, exam_card_id uuid not null references public.exam_cards(id) on delete restrict,
  quota_id uuid not null references public.monthly_quotas(id) on delete restrict, exam_date date not null, exam_type text not null default 'theory' check(exam_type in ('theory','practical')),
  status text not null default 'reserved' check(status in ('reserved','confirmed','cancelled','completed','failed','passed')),
  result_notes text, created_by uuid references auth.users(id) on delete set null, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create unique index if not exists exam_bookings_unique_active_student on public.exam_bookings(student_id,exam_date,exam_type) where status in ('reserved','confirmed');
create index if not exists exam_bookings_school_date_idx on public.exam_bookings(school_id,exam_date);

create table if not exists public.vehicles (
  id uuid primary key default gen_random_uuid(), school_id uuid not null default public.current_school_id() references public.schools(id) on delete restrict,
  label text not null, plate_number text not null, make text, model text, model_year integer, transmission text not null default 'يدوي',
  fuel_type text, license_category text not null default 'B', mileage integer not null default 0 check(mileage >= 0),
  status text not null default 'available' check(status in ('available','in_use','maintenance','retired')),
  insurance_expiry date, inspection_expiry date, notes text, created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(school_id,plate_number)
);
create table if not exists public.maintenance_records (
  id uuid primary key default gen_random_uuid(), school_id uuid not null default public.current_school_id() references public.schools(id) on delete restrict,
  vehicle_id uuid not null references public.vehicles(id) on delete restrict, title text not null, maintenance_date date not null default current_date,
  mileage integer, amount numeric(12,2) not null default 0 check(amount >= 0), vendor text, next_due_date date, notes text, created_at timestamptz not null default now()
);
create table if not exists public.fuel_records (
  id uuid primary key default gen_random_uuid(), school_id uuid not null default public.current_school_id() references public.schools(id) on delete restrict,
  vehicle_id uuid not null references public.vehicles(id) on delete restrict, fuel_date date not null default current_date,
  quantity_liters numeric(10,2), unit_price numeric(10,2), amount numeric(12,2) not null check(amount >= 0), mileage integer, created_at timestamptz not null default now()
);

create table if not exists public.instructors (
  id uuid primary key default gen_random_uuid(), school_id uuid not null default public.current_school_id() references public.schools(id) on delete restrict,
  full_name text not null, phone text, email text, license_categories text[] not null default array['B']::text[], active boolean not null default true,
  notes text, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.lessons (
  id uuid primary key default gen_random_uuid(), school_id uuid not null default public.current_school_id() references public.schools(id) on delete restrict,
  student_id uuid not null references public.students(id) on delete restrict, instructor_id uuid references public.instructors(id) on delete set null,
  vehicle_id uuid references public.vehicles(id) on delete set null, lesson_type text not null default 'practical' check(lesson_type in ('theory','practical')),
  starts_at timestamptz not null, ends_at timestamptz not null, status text not null default 'scheduled' check(status in ('scheduled','completed','absent','cancelled')),
  notes text, created_at timestamptz not null default now(), updated_at timestamptz not null default now(), check(ends_at > starts_at)
);
create index if not exists lessons_school_start_idx on public.lessons(school_id,starts_at);

create table if not exists public.site_settings (
  id uuid primary key default gen_random_uuid(), school_id uuid not null unique default public.current_school_id() references public.schools(id) on delete restrict,
  hero_title_ar text not null default 'الطريق إلى حريتك يبدأ من هنا.', hero_title_fr text not null default 'La liberté de conduire commence ici.',
  hero_subtitle_ar text, hero_subtitle_fr text, hero_image_url text, whatsapp_number text, public_email text, public_phone text,
  address text, city text, social_links jsonb not null default '{}'::jsonb, seo_title text, seo_description text,
  updated_at timestamptz not null default now()
);
create table if not exists public.pages (
  id uuid primary key default gen_random_uuid(), school_id uuid not null default public.current_school_id() references public.schools(id) on delete restrict,
  slug text not null, title_ar text not null, title_fr text, content_ar text, content_fr text, published boolean not null default false,
  seo_title text, seo_description text, updated_at timestamptz not null default now(), unique(school_id,slug)
);
create table if not exists public.post_categories (
  id uuid primary key default gen_random_uuid(), school_id uuid not null default public.current_school_id() references public.schools(id) on delete restrict,
  name_ar text not null, name_fr text, slug text not null, created_at timestamptz not null default now(), unique(school_id,slug)
);
create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(), school_id uuid not null default public.current_school_id() references public.schools(id) on delete restrict,
  title text not null, slug text not null, category text not null default 'نصائح', excerpt text, content text not null default '',
  cover_image_url text, status text not null default 'draft' check(status in ('draft','published','archived')),
  published_at timestamptz, seo_title text, seo_description text, author_id uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(school_id,slug)
);
create index if not exists posts_public_idx on public.posts(status,published_at desc);
create table if not exists public.audit_logs (
  id bigint generated always as identity primary key, school_id uuid references public.schools(id) on delete restrict,
  actor_id uuid references auth.users(id) on delete set null, action text not null, table_name text not null,
  record_id text, metadata jsonb not null default '{}'::jsonb, created_at timestamptz not null default now()
);

-- Enable RLS on every tenant/private table.
do $$ declare t text; begin
  foreach t in array array['schools','profiles','students','payments','expense_categories','expenses','exam_cards','monthly_quotas','exam_bookings','vehicles','maintenance_records','fuel_records','instructors','lessons','site_settings','pages','post_categories','posts','audit_logs'] loop
    execute format('alter table public.%I enable row level security',t);
  end loop;
end $$;

-- Profile: users can read their own profile; admins can read profiles for their school.
drop policy if exists profiles_select_self_or_admin on public.profiles;
create policy profiles_select_self_or_admin on public.profiles for select to authenticated
using (id = auth.uid() or (school_id = public.current_school_id() and public.is_school_admin()));
drop policy if exists profiles_admin_update on public.profiles;
create policy profiles_admin_update on public.profiles for update to authenticated
using (school_id = public.current_school_id() and public.is_school_admin()) with check (school_id = public.current_school_id() and public.is_school_admin());
drop policy if exists schools_member_read on public.schools;
create policy schools_member_read on public.schools for select to authenticated using (id = public.current_school_id());
drop policy if exists schools_admin_update on public.schools;
create policy schools_admin_update on public.schools for update to authenticated using (id = public.current_school_id() and public.is_school_admin()) with check (id = public.current_school_id() and public.is_school_admin());

-- Shared school-scoped policies. Accountant and instructors can read most operational records;
-- write permissions are narrower for sensitive finance and administration tables.
do $$ declare t text; begin
  foreach t in array array['students','vehicles','exam_cards','monthly_quotas','exam_bookings','maintenance_records','fuel_records','instructors','lessons','site_settings','pages','post_categories','posts','expense_categories'] loop
    execute format('drop policy if exists %I on public.%I', t||'_select_school',t);
    execute format('create policy %I on public.%I for select to authenticated using (school_id = public.current_school_id() and public.is_school_staff())', t||'_select_school',t);
    execute format('drop policy if exists %I on public.%I', t||'_insert_school',t);
    execute format('create policy %I on public.%I for insert to authenticated with check (school_id = public.current_school_id() and public.current_user_role() in (''admin'',''staff'',''editor''))', t||'_insert_school',t);
    execute format('drop policy if exists %I on public.%I', t||'_update_school',t);
    execute format('create policy %I on public.%I for update to authenticated using (school_id = public.current_school_id() and public.current_user_role() in (''admin'',''staff'',''editor'')) with check (school_id = public.current_school_id() and public.current_user_role() in (''admin'',''staff'',''editor''))', t||'_update_school',t);
    execute format('drop policy if exists %I on public.%I', t||'_delete_school',t);
    execute format('create policy %I on public.%I for delete to authenticated using (school_id = public.current_school_id() and public.is_school_admin())', t||'_delete_school',t);
  end loop;
end $$;

-- Finance read is available to authorized staff; only admin/accountant can mutate finance records.
do $$ declare t text; begin
  foreach t in array array['payments','expenses','audit_logs'] loop
    execute format('drop policy if exists %I on public.%I',t||'_select_school',t);
    execute format('create policy %I on public.%I for select to authenticated using (school_id = public.current_school_id() and public.is_school_staff())',t||'_select_school',t);
    execute format('drop policy if exists %I on public.%I',t||'_insert_school',t);
    execute format('create policy %I on public.%I for insert to authenticated with check (school_id = public.current_school_id() and public.current_user_role() in (''admin'',''accountant''))',t||'_insert_school',t);
    execute format('drop policy if exists %I on public.%I',t||'_update_school',t);
    execute format('create policy %I on public.%I for update to authenticated using (school_id = public.current_school_id() and public.current_user_role() in (''admin'',''accountant'')) with check (school_id = public.current_school_id() and public.current_user_role() in (''admin'',''accountant''))',t||'_update_school',t);
    execute format('drop policy if exists %I on public.%I',t||'_delete_school',t);
    execute format('create policy %I on public.%I for delete to authenticated using (school_id = public.current_school_id() and public.is_school_admin())',t||'_delete_school',t);
  end loop;
end $$;

-- Public visitors may read published articles; private drafts remain school-only.
drop policy if exists posts_public_read_published on public.posts;
create policy posts_public_read_published on public.posts for select to anon, authenticated using (status = 'published' and published_at is not null and published_at <= now());

-- updated_at triggers
create or replace function public.set_updated_at() returns trigger language plpgsql as $$ begin new.updated_at = now(); return new; end $$;
do $$ declare t text; begin foreach t in array array['schools','profiles','students','exam_cards','monthly_quotas','expenses','vehicles','instructors','lessons','site_settings','pages','posts'] loop
 execute format('drop trigger if exists set_updated_at on public.%I',t);
 execute format('create trigger set_updated_at before update on public.%I for each row execute function public.set_updated_at()',t);
end loop; end $$;

-- Payment ledger is the source of truth for payment history. This trigger updates paid_amount atomically.
create or replace function public.sync_student_paid_amount() returns trigger language plpgsql security definer set search_path=public as $$
begin
 if tg_op = 'INSERT' then update public.students set paid_amount = coalesce(paid_amount,0) + new.amount where id=new.student_id and school_id=new.school_id;
 elsif tg_op = 'DELETE' then update public.students set paid_amount = greatest(0,coalesce(paid_amount,0) - old.amount) where id=old.student_id and school_id=old.school_id;
 elsif tg_op = 'UPDATE' then
  if old.student_id = new.student_id then update public.students set paid_amount = greatest(0,coalesce(paid_amount,0) - old.amount + new.amount) where id=new.student_id and school_id=new.school_id;
  else update public.students set paid_amount = greatest(0,coalesce(paid_amount,0) - old.amount) where id=old.student_id and school_id=old.school_id; update public.students set paid_amount = coalesce(paid_amount,0) + new.amount where id=new.student_id and school_id=new.school_id; end if;
 end if; if tg_op = 'DELETE' then return old; else return new; end if;
end $$;
drop trigger if exists payments_sync_student on public.payments;
create trigger payments_sync_student after insert or update or delete on public.payments for each row execute function public.sync_student_paid_amount();

-- Atomic reservation function prevents monthly seat overbooking.
create or replace function public.reserve_exam_seat(p_student_id uuid,p_exam_card_id uuid,p_quota_month date,p_exam_date date,p_exam_type text default 'theory')
returns uuid language plpgsql security invoker set search_path=public as $$
declare q public.monthly_quotas%rowtype; new_booking uuid;
begin
 if not public.is_school_staff() then raise exception 'Not authorized'; end if;
 select * into q from public.monthly_quotas where exam_card_id=p_exam_card_id and quota_month=date_trunc('month',p_quota_month)::date and school_id=public.current_school_id() for update;
 if not found then raise exception 'Monthly quota not configured for this card'; end if;
 if q.quota_reserved >= q.quota_total then raise exception 'No exam seats remaining for this month'; end if;
 if exists(select 1 from public.exam_bookings where student_id=p_student_id and exam_date=p_exam_date and exam_type=p_exam_type and status in ('reserved','confirmed')) then raise exception 'Student already has an active booking for this exam date'; end if;
 insert into public.exam_bookings(school_id,student_id,exam_card_id,quota_id,exam_date,exam_type,created_by) values(public.current_school_id(),p_student_id,p_exam_card_id,q.id,p_exam_date,p_exam_type,auth.uid()) returning id into new_booking;
 return new_booking;
end $$;

-- Create the first school record after running this migration. Then create an Auth user and
-- add a profiles row for that user with role='admin' and the new school id (see README).

-- Keep reserved-seat counters synchronized when a booking is cancelled or restored.
create or replace function public.sync_exam_quota_reservation() returns trigger language plpgsql security definer set search_path=public as $$
begin
 if tg_op = 'INSERT' then
   if new.status in ('reserved','confirmed') then update public.monthly_quotas set quota_reserved=quota_reserved+1 where id=new.quota_id and school_id=new.school_id; end if;
 elsif tg_op = 'DELETE' then
   if old.status in ('reserved','confirmed') then update public.monthly_quotas set quota_reserved=greatest(0,quota_reserved-1) where id=old.quota_id and school_id=old.school_id; end if;
 elsif tg_op = 'UPDATE' then
   if old.quota_id = new.quota_id then
     if old.status not in ('reserved','confirmed') and new.status in ('reserved','confirmed') then update public.monthly_quotas set quota_reserved=quota_reserved+1 where id=new.quota_id and school_id=new.school_id;
     elsif old.status in ('reserved','confirmed') and new.status not in ('reserved','confirmed') then update public.monthly_quotas set quota_reserved=greatest(0,quota_reserved-1) where id=old.quota_id and school_id=old.school_id; end if;
   else
     if old.status in ('reserved','confirmed') then update public.monthly_quotas set quota_reserved=greatest(0,quota_reserved-1) where id=old.quota_id and school_id=old.school_id; end if;
     if new.status in ('reserved','confirmed') then update public.monthly_quotas set quota_reserved=quota_reserved+1 where id=new.quota_id and school_id=new.school_id; end if;
   end if;
 end if; if tg_op = 'DELETE' then return old; else return new; end if;
end $$;
drop trigger if exists exam_bookings_sync_quota on public.exam_bookings;
create trigger exam_bookings_sync_quota after insert or update or delete on public.exam_bookings for each row execute function public.sync_exam_quota_reservation();
