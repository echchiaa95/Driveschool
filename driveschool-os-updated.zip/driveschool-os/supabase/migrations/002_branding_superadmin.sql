-- DriveSchool OS: branding settings and platform superadmin support.
-- Run after 001_initial_schema.sql. Never expose SUPABASE_SERVICE_ROLE_KEY in the browser.

alter table public.profiles drop constraint if exists profiles_role_check;
alter table public.profiles add constraint profiles_role_check
  check (role in ('superadmin','admin','staff','accountant','instructor','editor'));

create or replace function public.is_platform_superadmin()
returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and active = true and role = 'superadmin'
  );
$$;

-- A platform superadmin can view school records for platform-wide reporting.
drop policy if exists schools_superadmin_read on public.schools;
create policy schools_superadmin_read on public.schools
  for select to authenticated
  using (public.is_platform_superadmin());

-- Allow superadmins to view profiles for platform-level account reporting.
drop policy if exists profiles_superadmin_read on public.profiles;
create policy profiles_superadmin_read on public.profiles
  for select to authenticated
  using (public.is_platform_superadmin());

-- Allow a platform superadmin to read audit records across schools.
drop policy if exists audit_logs_superadmin_read on public.audit_logs;
create policy audit_logs_superadmin_read on public.audit_logs
  for select to authenticated
  using (public.is_platform_superadmin());

-- Branding values are stored in schools (name/name_fr/logo_url/phone/address)
-- and site_settings (whatsapp_number). Existing RLS continues to scope updates
-- to the current school administrator.
