# DriveSchool OS — Auto-école management platform

A React + Vite + TypeScript frontend for a Moroccan driving school, with a cinematic bilingual Arabic/French public website and an operational admin dashboard. Supabase/PostgreSQL schema and row-level security are included.

> **Important:** The default dashboard uses clearly labeled sample/demo records when Supabase is not configured. Demo changes exist only in browser memory and are not persisted. Do not treat the sample amounts, student names, seat usage or card data as real records.

## Included in this starter

- Cinematic responsive landing page with Arabic/French switch, program sections, methodology, blog previews and contact CTA.
- Admin dashboard, KPI summaries, student list/search/add/delete, expense entry, vehicle entry, blog post creation, card quota overview and finance summaries.
- Supabase email/password sign-in when environment variables are configured.
- PostgreSQL schema for schools, user profiles/roles, students, payments, expenses, exam cards, monthly quotas, exam bookings, vehicles, maintenance, fuel, instructors, lessons, site settings, pages, blog posts and audit logs.
- Row Level Security policies and an atomic exam-seat reservation RPC that checks the monthly quota.
- Payment ledger trigger that synchronizes the student's paid amount.

## Run locally

Requirements: Node.js 20+ and npm.

```bash
npm install
cp .env.example .env
npm run dev
```

For a purely visual/demo preview, you can run without `.env`; the app will clearly display Demo mode. To persist real data, configure Supabase as below.

## Supabase setup

1. Create a Supabase project.
2. Open **SQL Editor** and run `supabase/migrations/001_initial_schema.sql`.
3. Insert the initial school row in SQL Editor:

   ```sql
   insert into public.schools (name, name_fr, slug, city)
   values ('مدرسة النجاح', 'Auto-école Al Najah', 'auto-ecole-al-najah', 'المغرب')
   returning id;
   ```

4. Create the manager account in **Authentication → Users → Add user**. Copy its UUID.
5. Add a profile for the manager in SQL Editor, replacing the UUID and school UUID with the actual values:

   ```sql
   insert into public.profiles (id, school_id, full_name, role, preferred_language)
   values ('AUTH-USER-UUID', 'SCHOOL-UUID', 'مدير المدرسة', 'admin', 'ar');
   ```

6. Copy the project URL and publishable/anon key from Supabase project settings into `.env`:

   ```dotenv
   VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
   VITE_SUPABASE_ANON_KEY=YOUR_PUBLIC_ANON_KEY
   ```

7. Restart Vite and sign in using the manager account. The RLS policies scope private data to the user's school.

**Security:** Never use the `service_role` secret in frontend code. For production, enable email confirmation/password policy as appropriate, set up backups, test every RLS policy with separate role accounts, and review the initial administrator provisioning procedure before inviting staff.

## Current implementation notes

- This is a working starter, not yet a fully audited production product. Some areas (editing full student profiles, recording payment transactions through the `payments` ledger, rental-contract workflow, monthly quota generation, lesson scheduling, image uploads, receipt/PDF generation and advanced SEO editing) are represented in the schema/UI plan but require the next implementation pass.
- The dashboard currently loads rows from Supabase after login and supports create/delete for students, create for expenses/vehicles/posts. Other areas are currently overview/read-oriented.
- Sample public contact information (including the WhatsApp CTA) must be replaced with the school's real details before publishing.
- Confirm the legal/administrative rules around exam cards and monthly quotas with the relevant Moroccan authority before relying on the seat quota model. The default value of 12 is configurable and is not represented as verified legal advice.

## Build

```bash
npm run build
npm run preview
```

## Branding settings and Superadmin (added)

1. Run `supabase/migrations/002_branding_superadmin.sql` after migration `001_initial_schema.sql`.
2. Deploy the secure school-creation function from the project root:

   ```bash
   supabase functions deploy admin-create-school
   ```

3. Ensure the Edge Function has the standard Supabase secrets configured (`SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`). Never put the service-role key in frontend environment variables.
4. Bootstrap the first platform superadmin manually using Supabase SQL Editor. Choose an existing authenticated user and an existing school UUID, then run:

   ```sql
   update public.profiles
   set role = 'superadmin'
   where id = 'AUTH_USER_UUID';
   ```

   The selected profile must already exist. Restrict this operation to a trusted owner.
5. Sign in with that user. The Superadmin navigation item appears only when the profile role is `superadmin`. The screen lists schools and invokes the Edge Function to create a school plus its manager account.
6. School managers can edit the Arabic/French school name, logo URL, WhatsApp number, phone, and address from Settings. Branding is saved to `schools` and `site_settings`.

The Superadmin account-creation endpoint verifies the caller's role server-side. It is not safe to create Auth users directly from the browser with a service-role key.
